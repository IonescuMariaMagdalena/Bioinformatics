from collections import defaultdict

ENZYMES = {
    "EcoRI":  {"site": "GAATTC", "cut_index": 1}, 
    "BamHI":  {"site": "GGATCC", "cut_index": 1}, 
    "HindIII":{"site": "AAGCTT", "cut_index": 1}, 
    "TaqI":   {"site": "TCGA",   "cut_index": 1},
    "HaeIII": {"site": "GGCC",   "cut_index": 2},
}

def find_cut_positions(dna_seq, site, cut_index):
    dna_seq = dna_seq.upper()
    site = site.upper()
    cut_positions = []

    start = 0
    while True:
        idx = dna_seq.find(site, start)
        if idx == -1:
            break
        cut_pos = idx + cut_index 
        cut_positions.append(cut_pos)
        start = idx + 1  

    return sorted(cut_positions)

def fragments_from_cuts(seq_len, cut_positions):
    if not cut_positions:
        return [seq_len]

    cuts = sorted(cut_positions)
    fragments = []
    prev = 0
    for c in cuts:
        fragments.append(c - prev)
        prev = c
    fragments.append(seq_len - prev)
    return fragments

def simulate_gel(fragments_per_enzyme, gel_height=20):
    all_lengths = [l for frags in fragments_per_enzyme.values() for l in frags]
    max_len = max(all_lengths)
    
    enzymes = list(fragments_per_enzyme.keys())
    num_lanes = len(enzymes)

    gel = [[" " for _ in range(num_lanes * 4)] for _ in range(gel_height)]
    
    for lane_idx, enzyme in enumerate(enzymes):
        fragments = fragments_per_enzyme[enzyme]
        for frag_len in fragments:
            relative = 1.0 - (frag_len / max_len)  
            line = int(relative * (gel_height - 1))
            col = lane_idx * 4 + 2

            gel[line][col] = "█"

    print("\nSimulated electrophoresis gel (top = large fragments, bottom = small fragments):\n")
    for row in gel:
        print("".join(row))

    label_line = ""
    for lane_idx, enzyme in enumerate(enzymes):
        col = lane_idx * 4 + 1
        label_line += " " * (col - len(label_line)) + enzyme[0]  # initială enzimă
    print("\nLane labels (first letter of enzyme):")
    print(label_line)
    print()
    for enzyme in enzymes:
        print(f"{enzyme[0]} = {enzyme}")

def main():
    dna_seq = (
        "ATGCGTACGATCGATCGATCGATCGATCGATCGATCGATCGA"
        "GAATTCGATCCGGATCCGGCCGAATTCGGATCCGGCCAAGCTT"
        "TCGATCGATCGATCGATCGATCGATCGATCGATCGATCGATC"
    )
    dna_seq = dna_seq.upper()
    seq_len = len(dna_seq)
    print(f"DNA length: {seq_len} bp\n")

    fragments_per_enzyme = {}

    for name, info in ENZYMES.items():
        site = info["site"]
        cut_idx = info["cut_index"]

        cut_pos = find_cut_positions(dna_seq, site, cut_idx)
        frags = fragments_from_cuts(seq_len, cut_pos)

        fragments_per_enzyme[name] = frags

        print(f"=== {name} ===")
        print(f"Recognition site: {site}")
        print(f"Number of cuts: {len(cut_pos)}")
        if cut_pos:
            print(f"Cut positions (0-based): {cut_pos}")
        else:
            print("No cleavage sites found.")
        print(f"Fragment lengths (bp): {frags}\n")

    simulate_gel(fragments_per_enzyme)

    combo = ["EcoRI", "BamHI"]
    combo_cuts = []
    for enz in combo:
        site = ENZYMES[enz]["site"]
        cut_idx = ENZYMES[enz]["cut_index"]
        combo_cuts.extend(find_cut_positions(dna_seq, site, cut_idx))
    combo_frags = fragments_from_cuts(seq_len, combo_cuts)

    print("=== Combined digest: EcoRI + BamHI ===")
    print(f"Total cuts: {len(combo_cuts)} at positions {sorted(combo_cuts)}")
    print(f"Fragment lengths (bp): {combo_frags}")

if __name__ == "__main__":
    main()
