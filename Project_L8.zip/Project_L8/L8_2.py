from collections import defaultdict
from Bio import Entrez, SeqIO

ENZYMES = {
    "EcoRI":  {"site": "GAATTC", "cut_index": 1},  
    "BamHI":  {"site": "GGATCC", "cut_index": 1},
    "HindIII":{"site": "AAGCTT", "cut_index": 1}, 
    "TaqI":   {"site": "TCGA",   "cut_index": 1}, 
    "HaeIII": {"site": "GGCC",   "cut_index": 2},  
}


def find_cut_positions(dna_seq, site, cut_index):
    dna_seq = dna_seq.upper()
    site = site.upper()
    cut_positions = []

    start = 0
    while True:
        idx = dna_seq.find(site, start)
        if idx == -1:
            break
        cut_pos = idx + cut_index
        cut_positions.append(cut_pos)
        start = idx + 1  

    return sorted(cut_positions)

def fragments_from_cuts(seq_len, cut_positions):
    if not cut_positions:
        return [seq_len]

    cuts = sorted(cut_positions)
    fragments = []
    prev = 0
    for c in cuts:
        fragments.append(c - prev)
        prev = c
    fragments.append(seq_len - prev)
    return fragments

def simulate_gel(frags_by_lane, title="Gel simulation", gel_height=20):
    print("\n" + "=" * 70)
    print(title)
    print("=" * 70)

    all_lengths = [l for frags in frags_by_lane.values() for l in frags]
    if not all_lengths:
        print("No fragments to display.")
        return

    max_len = max(all_lengths)
    lanes = list(frags_by_lane.keys())
    num_lanes = len(lanes)

    gel = [[" " for _ in range(num_lanes * 4)] for _ in range(gel_height)]

    for lane_idx, label in enumerate(lanes):
        fragments = frags_by_lane[label]
        for frag_len in fragments:
            relative = 1.0 - (frag_len / max_len) 
            line = int(relative * (gel_height - 1))
            col = lane_idx * 4 + 2
            gel[line][col] = "█"

    for row in gel:
        print("".join(row))

    label_line = ""
    for lane_idx, label in enumerate(lanes):
        col = lane_idx * 4 + 1
        lane_short = label[:3]  
        label_line += " " * (col - len(label_line)) + lane_short
    print(label_line)

    print("Lane legend:")
    for label in lanes:
        print(f"  {label[:3]} = {label}")
    print()

def download_influenza_sequences(n=10):
    search_term = (
        "Influenza A virus[Organism] "
        "AND hemagglutinin[Title] "
        "AND complete cds"
    )

    handle = Entrez.esearch(db="nucleotide", term=search_term, retmax=n)
    record = Entrez.read(handle)
    handle.close()

    ids = record["IdList"][:n]

    handle = Entrez.efetch(db="nucleotide", id=ids, rettype="fasta", retmode="text")
    seq_records = list(SeqIO.parse(handle, "fasta"))
    handle.close()

    result = []
    for rec in seq_records:
        seq = str(rec.seq).upper()
        desc = rec.description
        acc = rec.id
        result.append((acc, desc, seq))

    return result

def digest_genome_with_enzymes(seq):
    seq_len = len(seq)
    cuts_by_enzyme = {}
    frags_by_enzyme = {}

    for name, info in ENZYMES.items():
        site = info["site"]
        cut_idx = info["cut_index"]

        cut_pos = find_cut_positions(seq, site, cut_idx)
        frags = fragments_from_cuts(seq_len, cut_pos)

        cuts_by_enzyme[name] = cut_pos
        frags_by_enzyme[name] = frags

    return cuts_by_enzyme, frags_by_enzyme

def compute_common_fragments(all_frags_per_genome):
    enzymes = ENZYMES.keys()
    common_by_enzyme = {}

    for enz in enzymes:
        common = set(all_frags_per_genome[0][enz])
        for genome_frags in all_frags_per_genome[1:]:
            common &= set(genome_frags[enz])
        common_by_enzyme[enz] = common

    return common_by_enzyme

def remove_common_fragments(frags_by_enzyme, common_by_enzyme):
    diff = {}
    for enz, frags in frags_by_enzyme.items():
        common = common_by_enzyme[enz]
        diff[enz] = [f for f in frags if f not in common]
    return diff

def main():
    genomes = download_influenza_sequences(n=10)
    print(f"Downloaded {len(genomes)} Influenza A HA sequences from NCBI.\n")

    all_frags_per_genome = []  
    genome_labels = []

    for idx, (acc, desc, seq) in enumerate(genomes, start=1):
        label = f"{idx}_{acc}"
        genome_labels.append(label)

        seq_len = len(seq)
        print(f"Genome {idx}: {acc}")
        print(f"  Description: {desc}")
        print(f"  Length: {seq_len} bp\n")

        cuts_by_enzyme, frags_by_enzyme = digest_genome_with_enzymes(seq)
        all_frags_per_genome.append(frags_by_enzyme)

        for enz in ENZYMES.keys():
            cuts = cuts_by_enzyme[enz]
            frags = frags_by_enzyme[enz]
            print(f"  [{enz}] cuts: {len(cuts)}, positions: {cuts}")
            print(f"       fragments (bp): {frags}")
        print()

        frags_for_gel = {enz: frags_by_enzyme[enz] for enz in ENZYMES.keys()}
        simulate_gel(frags_for_gel, title=f"Genome {idx} – {acc} (full digest)")

    common_by_enzyme = compute_common_fragments(all_frags_per_genome)

    print("\nCommon fragments present in ALL genomes (per enzyme):")
    for enz, common_set in common_by_enzyme.items():
        print(f"  {enz}: {sorted(common_set) if common_set else 'None'}")

    diff_frags_per_genome = []
    for idx, frags_by_enzyme in enumerate(all_frags_per_genome, start=1):
        diff_frags = remove_common_fragments(frags_by_enzyme, common_by_enzyme)
        diff_frags_per_genome.append(diff_frags)

        frags_for_gel = {enz: diff_frags[enz] for enz in ENZYMES.keys()}
        simulate_gel(frags_for_gel,
                     title=f"Genome {idx} – difference-only digest (common bands removed)")

    frags_all_genomes_diff = {}
    for label, diff_frags in zip(genome_labels, diff_frags_per_genome):
        merged = []
        for enz in ENZYMES.keys():
            merged.extend(diff_frags[enz])
        merged = sorted(set(merged))
        frags_all_genomes_diff[label] = merged

    simulate_gel(frags_all_genomes_diff,
                 title="Global gel – ONLY differences between 10 Influenza A genomes")

if __name__ == "__main__":
    main()
