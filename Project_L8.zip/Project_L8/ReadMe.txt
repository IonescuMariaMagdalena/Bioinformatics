Dumitru Teodora Iulia 1242EA
Ionescu Maria Magdalena 1242EA
Sîrbu Constantin Radu 1242EA
