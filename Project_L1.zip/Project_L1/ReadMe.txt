Ionescu Maria-Magdalena
