import tkinter as tk

genetic_code = {
    'UUU':'Phe','UUC':'Phe','UUA':'Leu','UUG':'Leu','CUU':'Leu','CUC':'Leu','CUA':'Leu','CUG':'Leu',
    'AUU':'Ile','AUC':'Ile','AUA':'Ile','AUG':'Met','GUU':'Val','GUC':'Val','GUA':'Val','GUG':'Val',
    'UCU':'Ser','UCC':'Ser','UCA':'Ser','UCG':'Ser','CCU':'Pro','CCC':'Pro','CCA':'Pro','CCG':'Pro',
    'ACU':'Thr','ACC':'Thr','ACA':'Thr','ACG':'Thr','GCU':'Ala','GCC':'Ala','GCA':'Ala','GCG':'Ala',
    'UAU':'Tyr','UAC':'Tyr','UAA':'Stop','UAG':'Stop','CAU':'His','CAC':'His','CAA':'Gln','CAG':'Gln',
    'AAU':'Asn','AAC':'Asn','AAA':'Lys','AAG':'Lys','GAU':'Asp','GAC':'Asp','GAA':'Glu','GAG':'Glu',
    'UGU':'Cys','UGC':'Cys','UGA':'Stop','UGG':'Trp','CGU':'Arg','CGC':'Arg','CGA':'Arg','CGG':'Arg',
    'AGU':'Ser','AGC':'Ser','AGA':'Arg','AGG':'Arg','GGU':'Gly','GGC':'Gly','GGA':'Gly','GGG':'Gly'
}

def translate_rna_to_protein(rna_sequence):
    protein = []
    start = rna_sequence.find("AUG")
    if start == -1:
        return "No start codon (AUG) found."
    for i in range(start, len(rna_sequence), 3):
        codon = rna_sequence[i:i+3]
        if len(codon) < 3:
            break
        amino_acid = genetic_code.get(codon, "")
        if amino_acid == "Stop":
            break
        protein.append(amino_acid)
    return "-".join(protein)

root = tk.Tk()
root.title("Gene to Protein Translator")

tk.Label(root, text="Enter RNA sequence:").pack()
entry = tk.Entry(root, width=50)
entry.pack()

output_label = tk.Label(root, text="", fg="blue")
output_label.pack()

def translate():
    seq = entry.get().upper().replace(" ", "")
    output_label.config(text=translate_rna_to_protein(seq))

tk.Button(root, text="Translate", command=translate).pack(pady=5)
root.mainloop()
