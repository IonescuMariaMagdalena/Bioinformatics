Ionescu Maria Magdalena 1242EA, I worked alone.
